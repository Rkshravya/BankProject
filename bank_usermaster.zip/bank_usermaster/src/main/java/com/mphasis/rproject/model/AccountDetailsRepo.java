package com.mphasis.rproject.model;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mphasis.rproject.entity.AccountDetails;

@Repository
public interface AccountDetailsRepo extends JpaRepository<AccountDetails, String>{

	//AccountDetails updateAmount(Long amount);
@Transactional
@Modifying
@Query("update AccountDetails a set a.balance=a.balance-:amount where a.acc_number=:acc_number")
public int updateBalance(@Param("amount") Long amount,@Param("acc_number") String acc_number);

}
