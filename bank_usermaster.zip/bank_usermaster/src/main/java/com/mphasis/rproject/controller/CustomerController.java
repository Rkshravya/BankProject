package com.mphasis.rproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.rproject.entity.Customer;
import com.mphasis.rproject.model.CustomerService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class CustomerController 
{
	@Autowired
	CustomerService cs;
	
	@GetMapping("/customer")
	public List<Customer> getAllCustomers()
	{
		return cs.read(); 
	}
	
	@PostMapping("/customer")
	public Customer addCustomer(@RequestBody Customer customer)
	{
		return cs.create(customer);
	}
	
	@PutMapping("/customer")
	public Customer modifyCustomer(@RequestBody Customer customer)
	{
		return cs.update(customer);
	}
	
	@DeleteMapping("/customer/{customerId}")
	public void removeCustomer(@PathVariable("customerId")String customerId)
	{
		cs.delete(customerId);
	}
}
