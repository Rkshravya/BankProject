package com.mphasis.rproject.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="transaction_details")
public class TransactionDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long transaction_id;
	private Date dot;
	private String transaction_type;
	private Long amount;
	@OneToOne
	private AccountDetails accountDetails;
	@OneToOne
	private Payee payee ;

	public TransactionDetails() {}

	

	public TransactionDetails(Long transaction_id, Date dot, String transaction_type, Long amount,
			AccountDetails accountDetails, Payee payee) {
		super();
		this.transaction_id = transaction_id;
		this.dot = dot;
		this.transaction_type = transaction_type;
		this.amount = amount;
		this.accountDetails = accountDetails;
		this.payee = payee;
	}



	


	public Long getTransaction_id() {
		return transaction_id;
	}



	public void setTransaction_id(Long transaction_id) {
		this.transaction_id = transaction_id;
	}



	public Date getDot() {
		return dot;
	}


	public void setDot(Date dot) {
		this.dot = dot;
	}


	public String getTransaction_type() {
		return transaction_type;
	}


	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}


	public Long getAmount() {
		return amount;
	}


	public void setAmount(Long amount) {
		this.amount = amount;
	}
	
	public AccountDetails getAccountDetails() {
		return accountDetails;
	}

	public void setAccountDetails(AccountDetails accountDetails) {
		this.accountDetails = accountDetails;
	}

	public Payee getPayee() {
		return payee;
	}

	public void setPayee(Payee payee) {
		this.payee = payee;
	}



	@Override
	public String toString() {
		return "TransactionDetails [transaction_id=" + transaction_id + ", dot=" + dot + ", transaction_type="
				+ transaction_type + ", amount=" + amount + ", accountDetails=" + accountDetails + ", payee=" + payee
				+ "]";
	}

	



	












}
