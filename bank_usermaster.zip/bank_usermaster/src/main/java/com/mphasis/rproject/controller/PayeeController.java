package com.mphasis.rproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.mphasis.rproject.entity.Payee;

import com.mphasis.rproject.model.PayeeService;

////@RequestMapping("/")
@CrossOrigin(origins = {"http://localhost:4200", "*"})
@RestController
public class PayeeController 

{
	@Autowired
	 PayeeService ps;
	
	@PostMapping("/payee")
	public Payee addPayee(@RequestBody Payee payee)
	{
		return ps.create(payee);
	}
	@GetMapping("/payee")
	public List<Payee> getAllPayees()
	{
		return ps.read();
	}
	@GetMapping("/payee/{payeeId}")
	public Payee findPayeeById(@PathVariable("payeeId") String payeeId)
	{
		return ps.read(payeeId);
	}
	@PutMapping("/payee")
	public Payee modifyPayee(@RequestBody Payee payee)
	{
		return ps.update(payee);
	}
	@DeleteMapping("/payee/{payeeId}")
	public void removePayee(@PathVariable("payeeId")String payeeId)
	{
		ps.delete(payeeId);
	}
}
