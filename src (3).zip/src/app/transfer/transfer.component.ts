import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';

import { AccountDetails } from '../account-details';
import { AccountService } from '../account.service';
import { Payee } from '../payee';
import { PayeeService } from '../payee.service';
import { TransactionDetails } from '../transaction-details';

import { TransferService } from '../transfer.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})

export class TransferComponent implements OnInit {

  transferForm: any;
  user:any;
  name:string='';
  payeeIds:any;
  constructor(private fb: FormBuilder, private ts: TransferService, private router: Router, private as: AccountService, private ps: PayeeService) {
    this.transferForm = this.fb.group({
      acc_number: ['',[Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      payeeId: [''],
      dot: [''],
      transactionType: ['online'],
      amount: [''],
    });
    this.payeeIds=[];
  }

  ngOnInit(): void {
    this.ts.getAllPayees().subscribe((data)=>{
      this.payeeIds=data;
    });
  }
  get form() {
    return this.transferForm.controls;
  }
  ngDoCheck(): void {
    //check if local storage "user" is not null, then logged in. else, not logged in
    //this.name=localStorage.getItem("userName");
     var str = localStorage.getItem("user");
    console.log(str);
    if(str!=null)
    {
      this.user = <User><any>JSON.parse(str);
    }
    //this.user = <User><any>JSON.parse(str);
    var name:string;;
    if(str!=null)
    {
      name=this.user.userName;
    }
  }
  fnfundTransfer() {
    var transactionDetails = new TransactionDetails();
    var accountDetails: AccountDetails = new AccountDetails();
    var payeeId = this.transferForm.controls.payeeId.value;
    var payee: Payee = new Payee();


    //find account details object based on account num ber (using service subscribe)
    var acc_number = this.transferForm.controls.acc_number.value;
    console.log("fnfundTransfer: accnumber is " + acc_number);
    this.as.findAccountByAcN(acc_number).subscribe((data) => {
      console.log("Found account object is " + JSON.stringify(data));
      accountDetails = <any>data;

      transactionDetails.accountDetails = accountDetails;

      this.ps.findPayeeById(payeeId).subscribe((data) => {
        console.log("Payee found: " + JSON.stringify(data));
        payee = <any>data;


        transactionDetails.payee = payee;
        transactionDetails.dot = new Date();
        transactionDetails.transaction_type = 'online';

        transactionDetails.amount = this.form.amount.value;
        //accountDetails.balance-=this.form.amount.value;

        this.ts.fundTransfer(transactionDetails).subscribe((data)=>{
          console.log("Submitting the transaction objecgt as : "+JSON.stringify(transactionDetails));
          console.log("Obtained response as : "+JSON.stringify(data));
          var amount=transactionDetails.amount;
          this.as.updateBalance(acc_number,amount).subscribe((data)=>{
            console.log("After updating balance is"+JSON.stringify(accountDetails));
            alert(" Transaction Successful");
          })
        })

      });
    })





    //under construction
    // this.ts.fundTransfer(transactionDetails).subscribe(data=>{
    //   console.log(data);
    // });
  }




}
