import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BranchService } from '../branch.service';
import { User } from '../user';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent implements OnInit {

user:any;
  branchForm: any;
  branches: any;
    buttonDisabled:boolean=false;

  

  constructor(private fb: FormBuilder, private bs: BranchService) {
    this.branchForm = this.fb.group({
      bid: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      bname: [''],
      bcity: ['']
    },{validators:this.bidValidator()});
  }
ngDoCheck():void{
  var str = localStorage.getItem("user");
    console.log(str);
    if(str!=null)
    {
      this.user = <User><any>JSON.parse(str);
    }
    
    var name:string;;
    if(str!=null)
    {
      name=this.user.userName;
    }
    var role=this.user.role;
    if(role=="Admin")
    {
      this.buttonDisabled=true;
    }
    else{
      this.buttonDisabled=false;
    }
}
  bidValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.bid.errors && !formGroup.controls.bid.errors.bidValidator)
        return;
      var status = false;
      var bid = formGroup.controls.bid.value;
      //alert(bid.substring(0,1));
      if (bid.substring(0, 1) != 'B') {
        status = true;
      } else {
        var num = bid.substring(1);
        if (isNaN(num))
          status = true;
      }
      if (status)
        formGroup.controls.bid.setErrors({ 'bidValidator': true });
      else
        formGroup.controls.bid.setErrors(null);
    }
  }
  get form() {
    return this.branchForm.controls;
  }

  ngOnInit(): void {
    this.getAllBranches();
  }

  getAllBranches() {
    this.bs.getAllBranches().subscribe((data) => {
      console.log(data);
      this.branches = data;
    });
  }

  fnSelect(bid: string) {
    this.bs.findBranchById(bid).subscribe((data) => {
      console.log(data);
      // alert(JSON.stringify(data))
      this.branchForm.patchValue(data);
    });
  }


  fnFind() {
    var bid = this.branchForm.controls.bid.value;
    this.fnSelect(bid);
  }

  fnAdd() {
    var branch = this.branchForm.value;
    // this.bs.addBranch(branch).subscribe(this.fnCallBack);    
    this.bs.addBranch(branch).subscribe((data) => {
      console.log(data);
      this.getAllBranches();
    });
  }
  fnModify() {
    var branch = this.branchForm.value;
    this.bs.modifyBranch(branch).subscribe((data) => {
      console.log(data);
      this.getAllBranches();
    });
  }
  fnDelete() {
    var bid = this.branchForm.controls.bid.value;
    this.bs.deleteBranch(bid).subscribe((data) => {
      console.log(data);
      this.getAllBranches();
    });
  }
}
