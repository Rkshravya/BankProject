import { AccountDetails } from "./account-details";
import { Payee } from "./payee";

export class TransactionDetails {
    transaction_id: any;
	  dot:Date=new Date;
	 transaction_type:string='';
	 amount:string='';
	
	 accountDetails:AccountDetails=new AccountDetails();
	
	 payee :Payee=new Payee();
}
