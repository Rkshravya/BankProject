import { Component, OnInit, DoCheck } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { User } from '../user';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit, DoCheck {
  adminForm: any;
  transactions: any;
 //  user:any=null;
  user : User | any=new User();


  constructor(private fb: FormBuilder,private as: AdminService,private router:Router) { 
    this.adminForm = this.fb.group({
      TransactionId: [''],
      Amount: [''],
      DOT: [''],
      TransactionType: [''],
      AccountNumber: [''],
      PayeeId: [''],
    });
  }
  get form() {
    return this.adminForm.controls;
  }
  ngDoCheck() {
    var str = localStorage.getItem("user");
   if(str!=null)
   {
     this.user=JSON.parse(str);
     if(this.user!=null)
     {
       if(this.user.role!='Admin')
       {
         this.user=null;
         return;
       }
       else
         this.getAllTransactions();
     }
   }else{
     this.user=null;
   }

  }
  ngOnInit(): void {
    
  }
  getAllTransactions() {
    this.as.getAllTransactions().subscribe((data) => {
      console.log(data);
      this.transactions = data;
    });
  }

}
